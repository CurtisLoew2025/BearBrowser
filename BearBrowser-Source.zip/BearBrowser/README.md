# Bear Browser — Android source prototype

Native Java/WebView browser. Includes URL/search entry, back/forward/reload,
YouTube and Disney+ shortcuts, persistent bookmarks, clear-data controls,
fullscreen website video, adaptive layout and browsing-state restoration.

## Build and run

1. Install Android Studio on a Windows, macOS or Linux computer.
2. Extract this archive and open the BearBrowser folder as a project.
3. Install Android SDK Platform 35 and Build Tools 35.0.0 in SDK Manager.
4. Use JDK 17 and Gradle 8.11.1. This source archive does not bundle the Gradle
   wrapper binaries. Install Gradle 8.11.1, then run these commands from the
   project folder:

   gradle wrapper --gradle-version 8.11.1
   ./gradlew assembleDebug

   On Windows, use gradlew.bat assembleDebug for the second command.
5. APK output: app/build/outputs/apk/debug/app-debug.apk.
6. Enable USB debugging on a test phone and use Android Studio's Run action,
   or install the debug APK on your phone.

## Android Auto status

This version is a phone browser, not an enabled Android Auto browser.
Google's current documentation lists games as the only supported parked
Android Auto category. It lists browsers for Android Automotive OS, a
different platform. No game-category spoofing, motion overrides, head-unit
patches or restriction bypasses are included. This project will not appear
in the Android Auto launcher.

References checked October 10, 2026:
- https://developer.android.com/training/cars/parked/auto
- https://developer.android.com/training/cars/parked
- https://developer.android.com/reference/android/webkit/WebView
- https://developer.android.com/build/releases/agp-8-9-0-release-notes

## Limitations and privacy

Source prototype; not compiled or device-tested in the authoring environment
because Android SDK and Gradle are unavailable. No APK is included.
YouTube and Disney+ buttons open their websites. Playback, sign-in, DRM and
subscription compatibility are unverified; no protection circumvention is
implemented. Some services reject embedded browsers or require their apps.
Only HTTPS is allowed. TLS errors are never ignored. JavaScript and local
website storage are enabled; no native JavaScript bridge is exposed.
Camera/microphone and protected-media permission requests are denied.
Third-party cookies, popup windows, file uploads, downloads, password
management, tabs and external-app links are not implemented.
Cookies and website storage may retain sessions locally. Backups are disabled.
Clear data signs you out and retains bookmarks. This is not incognito mode.

## First device checks

- Open example.com and search for a phrase.
- Check back, forward, reload and phone rotation.
- Save a bookmark, close the app and verify it persists.
- Try a normal HTML5 video and enter/exit fullscreen.
- Test YouTube and Disney+ separately; record login/playback errors.
- Clear browsing data and verify sessions are removed.
