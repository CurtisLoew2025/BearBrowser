package com.curtis.browser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONException;

public class MainActivity extends Activity {
    private WebView web;
    private EditText address;
    private LinearLayout chrome;
    private FrameLayout root;
    private ProgressBar progress;
    private TextView status;
    private View video;
    private WebChromeClient.CustomViewCallback videoCallback;
    private SharedPreferences prefs;
    private static final String HOME = "https://www.google.com/";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("browser", MODE_PRIVATE);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(19,24,32));
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            android.graphics.Insets bars = android.os.Build.VERSION.SDK_INT >= 30
                ? insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout())
                : null;
            if (bars != null) v.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            else v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets;
        });
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        root.addView(body, new FrameLayout.LayoutParams(-1,-1));
        chrome = new LinearLayout(this);
        chrome.setOrientation(LinearLayout.VERTICAL);
        body.addView(chrome);
        LinearLayout row = new LinearLayout(this);
        chrome.addView(row);
        address = new EditText(this);
        address.setSingleLine(true);
        address.setTextColor(Color.WHITE);
        address.setHintTextColor(Color.LTGRAY);
        address.setHint("Website or search");
        address.setInputType(android.text.InputType.TYPE_CLASS_TEXT |
            android.text.InputType.TYPE_TEXT_VARIATION_URI);
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        row.addView(address,new LinearLayout.LayoutParams(0,dp(56),1));
        button(row,"Go",() -> navigate(address.getText().toString()));
        address.setOnEditorActionListener((v,action,event) -> {
            if (action == EditorInfo.IME_ACTION_GO) {
                navigate(address.getText().toString()); return true;
            }
            return false;
        });
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        LinearLayout actions = new LinearLayout(this);
        scroll.addView(actions);
        chrome.addView(scroll);
        button(actions,"Back",() -> { if(web.canGoBack()) web.goBack(); });
        button(actions,"Forward",() -> { if(web.canGoForward()) web.goForward(); });
        button(actions,"Reload",() -> web.reload());
        button(actions,"Home",() -> navigate(HOME));
        button(actions,"YouTube",() -> navigate("https://www.youtube.com/"));
        button(actions,"Disney+",() -> navigate("https://www.disneyplus.com/"));
        button(actions,"Save",this::saveBookmark);
        button(actions,"Bookmarks",this::showBookmarks);
        button(actions,"Clear data",this::clearData);
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        chrome.addView(progress,new LinearLayout.LayoutParams(-1,dp(3)));
        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setPadding(dp(12),dp(4),dp(12),dp(4));
        chrome.addView(status);
        web = new WebView(this);
        body.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSafeBrowsingEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                if ("https".equalsIgnoreCase(scheme)) return false;
                status.setText("Blocked link: only HTTPS websites are supported.");
                return true;
            }
            @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap icon) {
                address.setText(url); status.setText(""); progress.setVisibility(View.VISIBLE);
            }
            @Override public void onPageFinished(WebView view,String url) {
                address.setText(url); progress.setVisibility(View.GONE);
                CookieManager.getInstance().flush();
            }
            @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error) {
                if(request.isForMainFrame()) {
                    status.setText("Could not load page: " + error.getDescription());
                    progress.setVisibility(View.GONE);
                }
            }
            @Override public void onReceivedHttpError(WebView view,WebResourceRequest request,WebResourceResponse response) {
                if(request.isForMainFrame()) status.setText("Website returned HTTP " + response.getStatusCode());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view,int value) { progress.setProgress(value); }
            @Override public void onPermissionRequest(PermissionRequest request) { request.deny(); }
            @Override public void onShowCustomView(View view,CustomViewCallback callback) {
                if(video != null) { callback.onCustomViewHidden(); return; }
                video=view; videoCallback=callback;
                body.setVisibility(View.GONE);
                root.addView(video,new FrameLayout.LayoutParams(-1,-1));
            }
            @Override public void onHideCustomView() {
                hideVideo(); body.setVisibility(View.VISIBLE);
            }
        });
        setContentView(root);
        if(state == null || web.restoreState(state) == null) navigate(HOME);
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private void button(LinearLayout row,String label,Runnable action) {
        Button b = new Button(this); b.setText(label); b.setContentDescription(label);
        b.setMinHeight(dp(48)); row.addView(b);
        b.setOnClickListener(v -> action.run());
    }
    private void navigate(String input) {
        String value = input.trim();
        if(value.isEmpty()) return;
        Uri uri = Uri.parse(value);
        if(uri.getScheme() == null) {
            value = !value.contains(" ") && value.contains(".")
                ? "https://" + value
                : "https://www.google.com/search?q=" + Uri.encode(value);
            uri = Uri.parse(value);
        }
        if(!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null
            || uri.getUserInfo() != null) {
            status.setText("Enter an HTTPS website or search words."); return;
        }
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(address.getWindowToken(),0);
        web.requestFocus(); web.loadUrl(value);
    }
    private JSONArray bookmarks() {
        try { return new JSONArray(prefs.getString("bookmarks","[]")); }
        catch(JSONException e) { return new JSONArray(); }
    }
    private void saveBookmark() {
        String url = web.getUrl();
        if(url == null || !"https".equalsIgnoreCase(Uri.parse(url).getScheme())) return;
        JSONArray list = bookmarks();
        for(int i=0;i<list.length();i++) if(url.equals(list.optString(i))) {
            status.setText("Already bookmarked."); return;
        }
        list.put(url); prefs.edit().putString("bookmarks",list.toString()).apply();
        status.setText("Bookmark saved.");
    }
    private void showBookmarks() {
        JSONArray list = bookmarks();
        if(list.length() == 0) { status.setText("No bookmarks saved yet."); return; }
        String[] urls = new String[list.length()];
        for(int i=0;i<urls.length;i++) urls[i]=list.optString(i);
        new AlertDialog.Builder(this).setTitle("Bookmarks")
            .setItems(urls,(d,index) -> navigate(urls[index]))
            .setNegativeButton("Close",null).show();
    }
    private void clearData() {
        new AlertDialog.Builder(this).setTitle("Clear browsing data?")
            .setMessage("Signs you out of websites and clears history, cache and website storage. Bookmarks remain.")
            .setPositiveButton("Clear",(d,w) -> {
                web.stopLoading();
                CookieManager.getInstance().removeAllCookies(done -> {
                    CookieManager.getInstance().flush();
                    WebStorage.getInstance().deleteAllData();
                    web.clearCache(true); web.clearHistory(); web.clearFormData();
                    navigate(HOME); status.setText("Browsing data cleared.");
                });
            }).setNegativeButton("Cancel",null).show();
    }
    private void hideVideo() {
        if(video == null) return;
        root.removeView(video); video=null;
        WebChromeClient.CustomViewCallback cb=videoCallback; videoCallback=null;
        if(cb != null) cb.onCustomViewHidden();
        root.getChildAt(0).setVisibility(View.VISIBLE);
    }
    @Override public void onBackPressed() {
        if(video != null) hideVideo();
        else if(web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        web.saveState(state); super.onSaveInstanceState(state);
    }
    @Override protected void onPause() {
        web.onPause(); CookieManager.getInstance().flush(); super.onPause();
    }
    @Override protected void onResume() { super.onResume(); if(web != null) web.onResume(); }
    @Override protected void onDestroy() {
        hideVideo(); web.stopLoading();
        ((android.view.ViewGroup)web.getParent()).removeView(web);
        web.destroy(); super.onDestroy();
    }
}
